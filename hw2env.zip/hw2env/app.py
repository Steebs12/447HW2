from flask import Flask, request, redirect
from flask.templating import render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, migrate
 
app = Flask(__name__)
app.app_context().push()
# app.debug = True
 
# adding configuration for using a sqlite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
 
# Creating an SQLAlchemy instance
db = SQLAlchemy(app)
 
# Settings for migrations
migrate = Migrate(app, db)
 
# Models
class Profile(db.Model):
    # Id : Field which stores unique id for every row in
    # database table.
    # first_name: Used to store the first name if the user
    # last_name: Used to store last name of the user
    # Age: Used to store the age of the user
    id = db.Column(db.Integer, primary_key=True)
    first_last_name = db.Column(db.String(128), unique=False, nullable=False)
    id_number = db.Column(db.Integer, nullable=False)
    points = db.Column(db.Integer, nullable=False)
 
    # repr method represents how one object of this datatable
    # will look like
    def __repr__(self):
        return f"Name : {self.first_last_name}, points: {self.points}"
 
# function to render index page
@app.route('/')
def index():
    profiles = Profile.query.all()
    return render_template('index.html', profiles=profiles)
 
@app.route('/add_data')
def add_data():
    return render_template('add_profile.html')
 
# function to add profiles
@app.route('/add', methods=["POST"])
def profile():
    # In this function we will input data from the
    # form page and store it in our database. Remember
    # that inside the get the name should exactly be the same
    # as that in the html input fields
    print("hi")
    first_last_name = request.form.get("first_last_name")
    id_number = request.form.get("id_number")
    points = request.form.get("points")
 
    # create an object of the Profile class of models and
    # store data as a row in our datatable
    if first_last_name != '' and id_number != '' and points is not None:
        p = Profile(first_last_name=first_last_name, id_number=id_number, points=points)
        db.session.add(p)
        db.session.commit()
        return redirect('/')
    else:
        return redirect('/')
 
@app.route('/delete/<int:id>')
def erase(id):
     
    # deletes the data on the basis of unique id and
    # directs to home page
    data = Profile.query.get(id)
    db.session.delete(data)
    db.session.commit()
    return redirect('/')
 
if __name__ == '__main__':
    person1 = Profile(first_last_name="Steve Smith", id_number=211, points=80)
    db.session.add(person1)
    person2 = Profile(first_last_name= "Jian Wong", id_number= 122, points=92)
    db.session.add(person2)
    person3 = Profile(first_last_name= "Chris Peterson", id_number=213, points=91)
    db.session.add(person3)
    person4 = Profile(first_last_name="Sai Patel", id_number=524, points=94)
    db.session.add(person4)
    person5 = Profile(first_last_name="Andrew Whitehead", id_number=425, points=99)
    db.session.add(person5)
    person6 = Profile(first_last_name="Lynn Roberts", id_number=626, points=90)
    db.session.add(person6)
    person7 = Profile(first_last_name="Robert Sanders", id_number=287, points=75)
    db.session.add(person7)
    db.session.commit()
    app.run()
    db.session.delete(person1)
    db.session.delete(person2)
    db.session.delete(person3)
    db.session.delete(person4)
    db.session.delete(person5)
    db.session.delete(person6)
    db.session.delete(person7)
    db.session.commit()

